import React from 'react'

const Footer = () => {
  return (
    <div className='text-center bg-[#222222] text-[#6A6A6A] py-4'>Copyright &copy; New Thinking Ai, Inc. All rights reserved.</div>
  )
}

export default Footer
